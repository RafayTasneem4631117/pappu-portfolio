import { useEffect, useRef, useState } from 'react'
import { checkPdf } from '../../utils/pdfCheck.js'

/**
 * ProjectPDFModal — shows a project's PDF INSIDE the website (no new tab).
 *
 *  • Opens over the page with a dark, semi-transparent backdrop.
 *  • The PDF is shown with an <iframe>, using the browser's own PDF viewer,
 *    so every page can be scrolled.
 *  • Closes with the ✕ button, a click outside the window, or the Esc key.
 *  • While it is open the page behind cannot scroll; when it closes the page
 *    is exactly where the visitor left it.
 *  • If the PDF file is missing, a friendly message is shown instead.
 *
 * `project` comes from data/projects.js  →  { title, pdf, … }
 */
export default function ProjectPDFModal({ project, onClose }) {
  const closeRef = useRef(null)
  const [state, setState] = useState('checking') // 'checking' | 'ok' | 'missing'

  // 1) Is the PDF file really there?
  useEffect(() => {
    let cancelled = false
    setState('checking')
    checkPdf(project.pdf).then((ok) => { if (!cancelled) setState(ok ? 'ok' : 'missing') })
    return () => { cancelled = true }
  }, [project.pdf])

  // 2) Keyboard, focus and background-scroll lock (all undone on close)
  useEffect(() => {
    const previouslyFocused = document.activeElement
    const body = document.body
    const before = { overflow: body.style.overflow, paddingRight: body.style.paddingRight }

    // Lock page scrolling. Reserve the scrollbar's width so the page doesn't
    // "jump" sideways when the scrollbar disappears. The scroll POSITION is untouched.
    const scrollbar = window.innerWidth - document.documentElement.clientWidth
    body.style.overflow = 'hidden'
    if (scrollbar > 0) body.style.paddingRight = `${scrollbar}px`

    closeRef.current?.focus()

    const onKey = (e) => {
      if (e.key === 'Escape') { onClose(); return }
      if (e.key === 'Tab') { // keep Tab inside the window
        const items = document.querySelectorAll('.pdfm__dialog button, .pdfm__dialog a[href], .pdfm__dialog iframe')
        if (!items.length) return
        const first = items[0], last = items[items.length - 1]
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
      }
    }
    window.addEventListener('keydown', onKey)

    return () => {
      window.removeEventListener('keydown', onKey)
      body.style.overflow = before.overflow
      body.style.paddingRight = before.paddingRight
      previouslyFocused?.focus?.({ preventScroll: true }) // give focus back WITHOUT scrolling the page
    }
  }, [onClose])

  // #view=FitH makes the PDF fit the width of the window (so nothing is cut off).
  const src = `${project.pdf}#view=FitH&navpanes=0`

  return (
    <div
      className="pdfm"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()} // click on the dark area = close
    >
      <div className="pdfm__dialog" role="dialog" aria-modal="true" aria-labelledby="pdfm-title">
        <header className="pdfm__header">
          <h2 id="pdfm-title" className="pdfm__title">{project.title}</h2>
          <button ref={closeRef} type="button" className="pdfm__close" onClick={onClose} aria-label="Close PDF viewer">
            ✕
          </button>
        </header>

        <div className="pdfm__body">
          {state === 'ok' && (
            // key makes sure a different project always loads a fresh PDF
            <iframe key={project.pdf} className="pdfm__frame" src={src} title={`${project.title} PDF`} />
          )}

          {state === 'checking' && <p className="pdfm__msg" role="status">Loading PDF…</p>}

          {state === 'missing' && (
            <div className="pdfm__msg" role="status">
              <strong>The {project.title} PDF isn’t available yet.</strong>
              <span>Add the file at <code>assets{project.pdf}</code> and refresh the page.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
